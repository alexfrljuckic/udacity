const ErrorPage = () => {
    console.log('error!!!!')
    return (<div>Error</div>)
}

export default ErrorPage;