import { useEffect, useState } from "react";
import * as BooksAPI from "./BooksAPI";

const Book = ({ book,  onUpdateBook }) => {
  
  const [selectedOption,setSelectedOption] = useState("");

  useEffect(() => {
    BooksAPI.get(book.id).then(newBook => setSelectedOption(newBook.shelf));
  })

  const {
    thumbnail
  } = book.imageLinks ? book.imageLinks:'';

  const handleChange = (e) => {
    onUpdateBook(book, e.target.value)
    setSelectedOption(e.target.value)
  }
  const authors = book?.authors?.length &&
    (book.authors.map((author) => (
      <p key={author}>{author}</p>
    )));

  return (
    <li>
      <div className="book">
        <div className="book-top">
          <div
            className="book-cover"
            style={{
              width: 128,
              height: 193,
              backgroundImage:`url(${thumbnail})`
            }}>
          </div>
          <div className="book-shelf-changer">
            <select value={selectedOption} onChange={handleChange}>
              <option value="move to" disabled> Move to...</option>
              <option value="currentlyReading"> Currently Reading</option>
              <option value="wantToRead">Want to Read</option>
              <option value="read">Read</option>
              <option value="none">None</option>
            </select>
          </div>
        </div>
        <div className="book-title">{book.title}</div>
        <div className="book-authors">
          {authors}
        </div>
      </div>
    </li>
    )
}

export default Book;