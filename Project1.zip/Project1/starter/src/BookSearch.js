import Book from "./Book";
import { Link } from "react-router-dom";
import { useCallback, useEffect, useState } from "react";
import * as BooksAPI from "./BooksAPI";

const BookSearch = ({ updateBook }) => {
  const [query, setQuery] = useState("");
  const [queriedBooks, setQueriedBooks] = useState([]);

  const updateQuery = (searchText) => {
    setQuery(searchText);
  }

  const getQueriedBooks = useCallback(async () => {
    let result = [];
    if(query) {
      result = await BooksAPI.search(query, 30);
    }
    setQueriedBooks(result);
  },[query]);

  useEffect(() => {
    getQueriedBooks();
  }, [query, getQueriedBooks]);

  const books = 
    (query === "" || !queriedBooks.length) ? 
      <div>There are no books that match this search.</div> :
      queriedBooks.map((book) => (
        <Book book={book} key={book.id} onUpdateBook={updateBook}/>
      ));

    return (
        <div>
            <div className="search-books">
          <div className="search-books-bar">
            <Link to="/" className="close-search"/>
            <div className="search-books-input-wrapper">
              <input
                type="text"
                placeholder="Search by title, author, or ISBN"
                value={query}
                onChange={(event) => updateQuery(event.target.value)}
              />
            </div>
          </div>
          <div className="search-books-results">
            <ol className="books-grid">
              {
                books
              }
            </ol>
          </div>
        </div>
        </div>
    )
}

export default BookSearch;