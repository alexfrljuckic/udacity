import "./App.css";
import BookShelf from "./BookShelf";
import BookSearch from "./BookSearch";
import { Route, Routes } from "react-router-dom";
import { useEffect, useState } from "react";
import * as BooksAPI from "./BooksAPI";


function App() {
  const [books, setBooks] = useState([]);

  useEffect(() => {
      getBooks();
  },[])

  const updateBook = async (bookToUpdate, shelfToMoveTo) => {
      await BooksAPI.update(bookToUpdate, shelfToMoveTo);
      getBooks();
  }

  const getBooks = async () => {
      const res = await BooksAPI.getAll();
      setBooks(res);
  }

  return (
    <Routes>
      <Route exact path="/" element={
          <BookShelf books={books} updateBook={updateBook}/>
      }/>

      <Route path="/search" element={
        <BookSearch updateBook={updateBook}/>
      }/>
    </Routes>
  );
}

export default App;