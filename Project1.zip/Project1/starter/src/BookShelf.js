import { Link } from "react-router-dom";
import Shelf from "./Shelf";


const BookShelf = ({ books, updateBook }) => {
    const shelfCategories = [
        { title: "Currently Reading", shelfKey : "currentlyReading"},
        { title: "Want To Read", shelfKey : "wantToRead"},
        { title: "Read", shelfKey : "read"}
    ];
    
    return (
        <div className="list-books">
          <div className="list-books-title">
            <h1>MyReads</h1>
          </div>
          <div className="list-books-content">
            <div>
                {
                    shelfCategories.map((category) => (
                        <Shelf category={category} books={books} updateBook={updateBook} key={category['title']}/>
                    ))
                }
            </div>
          </div>
          <div className="open-search">
            <Link to="/search"/>
          </div>
        </div>
    )
}

export default BookShelf;