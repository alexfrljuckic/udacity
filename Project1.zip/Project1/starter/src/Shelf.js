import Book from "./Book";

const Shelf = ({ category, books, updateBook }) => {
    const {
        title: categoryTitle,
        shelfKey: categoryKey
    } = category;

    return (
        <div className="bookshelf" >
                    <h2 className="bookshelf-title" name={categoryTitle}>{categoryTitle}</h2>
                    <div className="bookshelf-books">
                            <ol className="books-grid">
                                {   
                                    books.length &&
                                    books.map((book) => (
                                        (book.shelf === categoryKey && <Book key={book.id} book={book} onUpdateBook={updateBook}/>)
                                    ))
                                }
                            </ol>
                    </div>
                </div>
    )
}

export default Shelf;